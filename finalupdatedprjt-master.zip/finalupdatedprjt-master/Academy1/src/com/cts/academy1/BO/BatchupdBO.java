package com.cts.academy1.BO;

public class BatchupdBO {

}
